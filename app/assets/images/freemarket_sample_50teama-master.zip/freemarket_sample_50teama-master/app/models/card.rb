class Card < ApplicationRecord
  belongs_to :user
end
