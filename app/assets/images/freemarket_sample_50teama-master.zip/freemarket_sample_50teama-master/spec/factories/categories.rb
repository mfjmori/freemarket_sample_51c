FactoryBot.define do
  factory :category do
    name          {"靴"}
  end
end
